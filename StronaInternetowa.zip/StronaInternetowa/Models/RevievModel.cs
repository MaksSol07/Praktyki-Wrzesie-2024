namespace StronaInternetowa.Models;

public class ReviewModel
{
    public string GameTitle { get; set; }
    public double Rating { get; set; }
    public string ReviewText { get; set; }
}
