namespace StronaInternetowa.Models;

public class NewsModel
{
    public string Title { get; set; }
    public string Content { get; set; }
    public DateTime Date { get; set; }
}
