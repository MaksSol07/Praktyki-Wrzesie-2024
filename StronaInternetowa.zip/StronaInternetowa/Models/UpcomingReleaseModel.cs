namespace StronaInternetowa.Models;

public class UpcomingReleaseModel
{
    public string GameTitle { get; set; }
    public DateTime ReleaseDate { get; set; }
}

