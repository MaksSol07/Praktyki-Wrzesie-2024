namespace StronaInternetowa.Controllers;

public class HomeController : Controller
{
    public IActionResult Reviews()
    {
        var reviews = new List<ReviewModel>
        {
            new ReviewModel { GameTitle = "Elden Ring", Rating = 9.8, ReviewText = "Arcydzie�o od FromSoftware." },
            new ReviewModel { GameTitle = "God of War Ragnarok", Rating = 9.5, ReviewText = "Kratos powraca w epickiej sadze." }
        };

        return View(reviews);
    }
}

