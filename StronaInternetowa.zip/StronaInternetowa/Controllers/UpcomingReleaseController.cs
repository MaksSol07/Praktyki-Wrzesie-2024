namespace StronaInternetowa.Controllers;

public class HomeController : Controller
{
    public IActionResult UpcomingReleases()
    {
        var releases = new List<UpcomingReleaseModel>
        {
            new UpcomingReleaseModel { GameTitle = "Starfield", ReleaseDate = new DateTime(2024, 11, 12) },
            new UpcomingReleaseModel { GameTitle = "Hogwarts Legacy", ReleaseDate = new DateTime(2024, 12, 5) }
        };

        return View(releases);
    }
}
