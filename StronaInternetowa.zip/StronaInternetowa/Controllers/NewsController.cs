namespace StronaInternetowa.Controllers;

public class HomeController : Controller
{
    public IActionResult News()
    {
        var news = new List<NewsModel>
        {
            new NewsModel { Title = "Cyberpunk 2077", Content = "Nowy dodatek zapowiedziany!", Date = DateTime.Now },
            new NewsModel { Title = "GTA VI", Content = "Zwiastun pokazuje wi�kszy otwarty �wiat!", Date = DateTime.Now.AddDays(-1) }
        };

        return View(news);
    }
}
